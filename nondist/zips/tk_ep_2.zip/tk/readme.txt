TIME KEEPERS
============
Time Keepers is a game I made. You shoot things, steal things and hide in closets.

This is release 2.

Time from epoch to release 1: 3 months 5 days
Time from release 1 to release 2: 3 years 2 months 1 day

Release 3? At some point I hope.

/***********
* Controls *
***********/
Space	- Shoot/OK
LShift	- Medkit/Cancel
A	- Aim
S	- Target things to steal
Z	- Weapon switch up
X	- Weapon switch down
Tab	- Open PDA


These settings can be changed in the keyconfig menu. Joystick setups are also customizable.


/*******************************
*  Other peoples stuff I used  *
*******************************/
RageCage - A*, Blur library
Feyr - HookPQueue
Zip - Many small snipets
TomT64 - VOpenCHR
Choris - Basis for the chr's
Grue - 3*5 Font
Interference - The rest of the fonts
Sully Simple Type - Dual Retrace Idea - Implemented into hook.vc



(C) 2008 Gyasi Grey - All source code, images.
All sound and music used without permission. I'm a freeloader.