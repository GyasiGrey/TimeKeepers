TIME KEEPERS
============
Time Keepers is a story driven action oriented game. Think Metal Gear Solid cross bred with Thief and a bit of Deus Ex thrown in for flavor, all from an overhead view.

This is the introduction area and first mission. I plan on having 4 other missions but if I waited to finish all the missions before releasing the game It would never get finished.

All the source code is included in the VC directory, so feel free to muck around with it. For the most part it should be well commented, and the only really scary stuff is in the events in the map vc. You can use parts of this code, but give credit where credit is due.

/***********
* Controls *
***********/
Space	- Shoot
A	- Aim
S	- Target things to steal
Z	- Weapon switch up
X	- Weapon switch down

All these can be changed in the keyconfig menu. 

As a side note you can also use a joystick. The default settings are setup for my PSX pad, but you can change them in the keyconfig menu as well. So all you nuts that use a SNES pad, go for it.

/******************************************
* Aaahhh! I screwed up my button configs! *
******************************************/
Tis not a problem grashopper. Delete buttons.sav and all will be restored to its default values. Well the buttons at least.

/**************************************************
* Particles, Lighting Effects and Ambient Sounds? *
**************************************************/
Yeah well I hate maping so much that I have to make little things like this to keep myself enthused about the project. Plus it adds to the effect. Hopefully.

/*******************************
*  Other peoples stuff I used  *
*******************************/
RageCage - A*, Blur library
Overkill - V3Console
Feyr - HookPQueue
Zip - Many small snipets
TomT64 - VOpenCHR
Choris - Basis for the chr's
Grue - 3*5 Font
Sully Simple Type - Dual Retrace Idea - Implemented into hook.vc



(C) 2005 Gyasi Grey - All source code, images.
All sound and music used without permission